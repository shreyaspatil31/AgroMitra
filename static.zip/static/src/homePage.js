document.addEventListener("DOMContentLoaded", function() {
    let slideIndex = 0;

    function moveSlide(step) {
        const slides = document.querySelectorAll(".carousel-slide");
        const dots = document.querySelectorAll(".corousel-dot");
        slideIndex += step;

        if (slideIndex >= slides.length) {
            slideIndex = 0;
        } else if (slideIndex < 0) {
            slideIndex = slides.length - 1;
        }

        const slideWidth = slides[0].clientWidth;
        const moveX = slideIndex * -slideWidth;
        document.querySelector(".carousel-slides").style.transform = `translateX(${moveX}px)`;

        dots.forEach(dot => dot.classList.remove('active'));
        dots[slideIndex].classList.add('active');
    }

    function autoSlide() {
        moveSlide(1);
        setTimeout(autoSlide, 5000);
    }

    autoSlide();

    const dots = document.querySelectorAll(".corousel-dot");
    dots.forEach((dot, index) => {
        dot.addEventListener("click", function() {
            const step = index - slideIndex;
            moveSlide(step);
        });
    });
});
