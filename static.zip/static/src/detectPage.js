(function () {
    let menuOpened = false;

    const menu = document.getElementById("menu");
    const menuButton = document.getElementById("menuButton");
    const dropdownMenu = document.getElementById("dropdownMenu");
    const select = dropdownMenu.querySelector("#select");
    const options = dropdownMenu.querySelector("#options");
    const selected = dropdownMenu.querySelector("#selected");
    const arrow = select.querySelector("#arrow");
    const loadButton = document.getElementById("loadButton");
    const imageBlock = document.getElementById("imageBlock");
    const fileInput = document.getElementById("fileInput");
    const predictButton = document.getElementById("predictButton");
    const predictedDisease = document.getElementById("predictedDisease");

    const makeUse = document.getElementById("makeUse");
    const contents = document.getElementById("contents");
    const companyName = document.getElementById("companyName");

    menuButton.addEventListener("click", toggleMenu);
    select.addEventListener("click", toggleDropdown);
    options.addEventListener("click", handleOptionClick);
    loadButton.addEventListener("click", loadFile);
    fileInput.addEventListener("change", handleFileInputChange);
    predictButton.addEventListener("click", processData)

    function fetchBlob(url) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.responseType = 'blob';
            xhr.onload = function () {
                if (xhr.status === 200) {
                    resolve(xhr.response);
                } else {
                    reject(Error('Image loading failed; error code:' + xhr.statusText));
                }
            };
            xhr.onerror = function () {
                reject(Error('There was a network error.'));
            };
            xhr.send();
        });
    }

    function setData(response) {
        predictedDisease.innerText = response.name;
        makeUse.innerText = response.solution.makeUse;
        contents.innerText = response.solution.content;
        companyName.innerText = response.solution.company;
    }

    function processData() {
        var cropType = selected.innerText.toUpperCase();
        var imageSrc = imageBlock.querySelector("img").src;

        fetchBlob(imageSrc)
            .then(function (blob) {
                var formData = new FormData();
                formData.append('cropType', cropType);
                formData.append('image', blob);

                var xhr = new XMLHttpRequest();
                xhr.open('POST', '/upload', true);
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        setData(response);
                    } else {
                        console.error('Error:', xhr.statusText);
                    }
                };
                xhr.onerror = function () {
                    console.error('Request failed');
                };
                xhr.send(formData);
            })
            .catch(function (error) {
                console.error('Error fetching blob:', error);
            });
    }

    function toggleMenu() {
        menuOpened = !menuOpened;
        menu.style.display = menuOpened ? "flex" : "none";
    }

    function toggleDropdown() {
        options.classList.toggle("hidden");
        arrow.classList.toggle("rotated");
    }

    function handleOptionClick(event) {
        if (event.target.tagName === "LI") {
            selected.textContent = event.target.innerText;
            options.classList.add("hidden");
            arrow.classList.add("rotated");
        }
    }

    function loadFile() {
        fileInput.click();
    }

    function handleFileInputChange(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const image = document.createElement('img');
                image.src = e.target.result;
                imageBlock.innerHTML = '';
                imageBlock.appendChild(image);
            };
            reader.readAsDataURL(file);
        }
    }
})();
