homeButton = document.getElementById("homeButton");
detectButton = document.getElementById("detectButton");

homeButton.addEventListener("click", () => {
    window.location.href = "/";
});

detectButton.addEventListener("click", () => {
    window.location.href = "/detect";
});

let menuOpened = false;

const menu = document.getElementById("menu");
const menuButton = document.getElementById("menuButton");

function toggleMenu() {
    menuOpened = !menuOpened;
    menu.style.display = menuOpened ? "flex" : "none";
}

menuButton.addEventListener("click", toggleMenu);
